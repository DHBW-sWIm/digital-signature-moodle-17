<?php
$capabilities = array(
    'local/digitalsignature:config' => array(
        'captype'      => 'write',
        'contextlevel' => CONTEXT_SYSTEM,
        'archetypes'   => array(
        )
    )
    // Add more capabilities here ...
);
