<?php
defined('MOODLE_INTERNAL') || die();


function local_digitalsignature_extend_navigation(global_navigation $nav) {
    $context = context_system::instance();

    if(isloggedin()) {

            $link = new moodle_url('/local/digitalsignature/index.php');
            $node = $nav->add('Digital Signature',$link,navigation_node::TYPE_CUSTOM,
                null,
                'digitalsignature'

            );
            $node->showinflatnavigation = true;


    }

}