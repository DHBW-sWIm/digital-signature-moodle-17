<?php
// This file is part of the Local Analytics plugin for Moodle
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 */




require_once(dirname(__FILE__, 3) . '/config.php');
require_once(__DIR__ . '/lib.php');
require_once(__DIR__ . '/ds_config_form.php');
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/vendor/docusign/esign-client/autoload.php';

use local_digitalsignature\Services\CodeGrantService;

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $input = filter_input_array(INPUT_GET);
} else {
    $input = filter_input_array(INPUT_POST);
};




global $DB, $PAGE, $OUTPUT;

$PAGE->set_title('Authorization');
if(!isset($form)) {
    $form = new ds_config_form();
}
$PAGE->set_heading('Digital Signature');
echo $OUTPUT->header();

$authService = new CodeGrantService();
if ($form->is_submitted()) {
    //TODO: please do a proper form validation

    $_SESSION['DS_CONFIG'] = (array) $form->get_data();
    $authService->login();
}

if (isset($_GET['code'])) {
    $authService->authCallback();
    unset($_GET['code']);
}
$form->display();
echo $OUTPUT->footer();
