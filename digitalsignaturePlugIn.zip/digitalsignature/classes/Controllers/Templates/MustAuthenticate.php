<?php


namespace Example\Controllers\Templates;

class MustAuthenticate
{
    public function controller()
    {
        $method = $_SERVER['REQUEST_METHOD'];
        if ($method == 'GET') {
            $this->getController();
        };
    }

    private function getController()
    {
        $GLOBALS['twig']->display('must_authenticate.php', [
            'title' => 'Please authenticate with DocuSign',
            'show_doc' => false
        ]);
    }
}
