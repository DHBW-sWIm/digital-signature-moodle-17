<?php



namespace local_digitalsignature\Services;

use local_digitalsignature\Controllers\Auth\DocuSign;

class CodeGrantService
{
    /**
     * Set flash for the current user session
     * @param $msg string
     */
    public function flash(string $msg): void
    {
        if (!isset($_SESSION['flash'])) {
            $_SESSION['flash'] = [];
        }
        array_push($_SESSION['flash'], $msg);
    }

    /**
     * Checker for the CSRF token
     */
    function checkToken(): void
    {
        if (!(isset($_POST['csrf_token']) &&
            hash_equals($_SESSION['csrf_token'], $_POST['csrf_token']))) {
            # trouble!
            $this->flash('CSRF token problem!');
            header('Location: ' . $GLOBALS['app_url']);
            exit;
        }
    }

    /**
     * Get OAUTH provider
     * @return DocuSign $provider
     */
    function get_oauth_provider(): DocuSign
    {
        global $DB;
        //for the first login the data is handed through the session
        if (isset($_SESSION['DS_CONFIG'])) {
            return new DocuSign([
                'clientId' => $_SESSION['DS_CONFIG']['ds_client_id'],
                'clientSecret' => $_SESSION['DS_CONFIG']['ds_client_secret'],
                'redirectUri' => $_SESSION['DS_CONFIG']['app_url'] . '/index.php?page=ds_callback',
                'authorizationServer' => $_SESSION['DS_CONFIG']['authorization_server'],
                'allowSilentAuth' => true
            ]);
        } else {
            $records = $DB->get_records('ds_config');
            $record = current($records);
            return new DocuSign([
                'clientId' => $record['ds_client_id'],
                'clientSecret' => $record['ds_client_secret'],
                'redirectUri' => $record['app_url'] . '/index.php?page=ds_callback',
                'authorizationServer' => $record['authorization_server'],
                'allowSilentAuth' => true
            ]);
        }
    }

    /**
     * DocuSign login handler
     */
    function login(): void
    {
        $provider = $this->get_oauth_provider();
        $authorizationUrl = $provider->getAuthorizationUrl();
        // Get the state generated for you and store it to the session.
        $_SESSION['oauth2state'] = $provider->getState();
        // Redirect the user to the authorization URL.
        redirect($authorizationUrl);
        exit;
    }

    /**
     * DocuSign login handler
     * @param $redirectUrl
     */
    function authCallback(): void
    {
        global $DB;
        $ds_config = new \stdClass();
        $provider = $this->get_oauth_provider();
        try {
            // Try to get an access token using the authorization code grant.
            $accessToken = $provider->getAccessToken('authorization_code', [
                'code' => $_GET['code']
            ]);

            // We have an access token, which we may use in authenticated
            // requests against the service provider's API.
            if (isset($_SESSION['DS_CONFIG'])) {
                $ds_config = (object) $_SESSION['DS_CONFIG'];
            }
            $ds_config->ds_access_token = $accessToken->getToken();
            $ds_config->ds_refresh_token = $accessToken->getRefreshToken();
            $ds_config->ds_expiration = $accessToken->getExpires(); # expiration time.

            // Using the access token, we may look up details about the
            // resource owner.
            $user = $provider->getResourceOwner($accessToken);
            $ds_config->ds_user_name = $user->getName();
            $ds_config->ds_user_email = $user->getEmail();

            $account_info = $user->getAccountInfo();
            $base_uri_suffix = '/restapi';
            $ds_config->ds_account_id = $account_info["account_id"];
            $ds_config->ds_account_name = $account_info["account_name"];
            $ds_config->ds_base_path = $account_info["base_uri"] . $base_uri_suffix;

            $DB->insert_record('ds_config', $ds_config);
            unset($_SESSION['DS_CONFIG']);
        } catch (\Exception $e) {
            // Failed to get the access token or user details.
            exit($e->getMessage());
        }
        /*  if (! $redirectUrl) {
              $redirectUrl = $GLOBALS['app_url'];
          }
          redirect($redirectUrl);*/
        exit;
    }
}
