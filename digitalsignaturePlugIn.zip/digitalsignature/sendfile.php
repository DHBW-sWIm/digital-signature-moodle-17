<?php
// This file is part of the Local Analytics plugin for Moodle
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


/**
 */
require_once(dirname(__FILE__, 3) . '/config.php');
require_once(__DIR__ . '/lib.php');
require_once(__DIR__ . '/ds_config_form.php');
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/vendor/docusign/esign-client/autoload.php';
require_once __DIR__ . '/ds_config.php';


if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $input = filter_input_array(INPUT_GET);
} else {
    $input = filter_input_array(INPUT_POST);
};

use local_digitalsignature\Services\CodeGrantService;
use local_digitalsignature\Controllers\Templates\SigningViaEmail;

global $DB, $PAGE, $OUTPUT, $USER;

require_login();
$signers[0] = ['email' => 'gaithzakrea@gmail.com', 'name' =>'Gith',
            'recipient_id' => "1", 'routing_order' => "1"];
$signers[1] = ['email' => 'mazen.abbas@outlook.de', 'name' =>'Mazen',
            'recipient_id' => "2", 'routing_order' => "2"];
$signing = new SigningViaEmail($signers,'local/digitalsignature/public/demo_documents/ausarbeitung.pdf');