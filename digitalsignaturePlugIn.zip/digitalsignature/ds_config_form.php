<?php
//moodleform is defined in formslib.php
require_once("$CFG->libdir/formslib.php");

class ds_config_form extends moodleform {
    //Add elements to form
    public function definition() {
        global $CFG , $DB;

/*        $params = $DB->get_records('ds_config');
        $params = current($params);
        if(empty($params)){
            $params->ds_client_id = ' ';
            $params->ds_client_secret = ' ';
            $params->ds_user_email = ' ' ;
            $params->ds_user_name = ' ';
            $params->authorization_server = '  ';
            $params->app_url = ' ';
        }*/
        $mform = $this->_form; // Don't forget the underscore!

        $mform->addElement('text', 'ds_client_id', 'DocuSign integration key', 'size = 70');// Add elements to your form
        $mform->addElement('text', 'ds_client_secret', 'DocuSign integration key\'s secret' , 'size = 70');// // Add elements to your form
        $mform->addElement('text', 'signer_email' , 'Signer Email' , 'size = 70');/// Add elements to your form
        $mform->addElement('text', 'signer_name' , 'Signer Name' , 'size = 70');// Add elements to your form
        $mform->addElement('text', 'authorization_server' , 'Authorization Server' , 'size = 70'); // Add elements to your form
        $mform->addElement('text', 'app_url' , 'App Url' , 'size = 70');//elements to your form
        $mform->addRule('signer_email','Please enter a valid email','email');
        $mform->addElement('submit', 'submitbutton', 'Connect');

    }
    //Custom validation should be added here
    function validation($data, $files) {
        return array();
    }
}